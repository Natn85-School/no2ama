package autohaus;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Dateihandler
{
	protected BufferedReader reader;
	protected BufferedWriter writer;
	
	
	ArrayList<Auto> autoArray = new ArrayList<Auto>();
	String zeile;
	
	public ArrayList<Auto> readFromTxt(String filename)
	{
		try
		{
			while((zeile = reader.readLine()) != null)
			{
				String[] teile = zeile.split(";");
				String modell = teile[0];
				String farbe = teile[1];
				int ps = Integer.parseInt(teile[2]);
				double preis = Double.parseDouble(teile[3]);
				
				autoArray.add(new Auto(modell, farbe, ps, preis));
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return autoArray;
	}
}