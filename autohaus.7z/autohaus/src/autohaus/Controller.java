package autohaus;

import java.awt.event.ActionListener;

public class Controller implements ActionListener
{
	private AutoGui aGui;
	
}
