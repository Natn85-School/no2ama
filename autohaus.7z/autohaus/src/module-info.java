/**
 * 
 */
/**
 * 
 */
module autohaus
{
	requires java.desktop;
}