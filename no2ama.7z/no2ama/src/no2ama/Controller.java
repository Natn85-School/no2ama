package no2ama;

public class Controller
{

}
