package no2ama;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;

import java.awt.event.ActionEvent;

public class Controller implements ActionListener
{
	private No2ama view;
	private BestellungsSystem model;
	DefaultListModel<Artikel> listModel = new DefaultListModel<>();
	
	public Controller(No2ama view, BestellungsSystem model)
	{
		this.view = view;
		this.model = model;
		
		view.getBtnWarenkorb().addActionListener(this);
		view.getBtnArtikel().addActionListener(this);
		view.getBtnBestellungAbschicken().addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == view.getBtnWarenkorb())
		{
			addToWarenkorb();
		}
		else if (e.getSource() == view.getBtnArtikel())
		{
			removeFromWarenkorb();
		} 
		else if (e.getSource() == view.getBtnBestellungAbschicken())
		{
			submitBestellung();
		}
	}
	
	private void addToWarenkorb()
	{
		int selectedIndex = view.getArtikelList().getSelectedIndex();
		
		if(selectedIndex == -1) return;
		
		Artikel selected = model.getArtikelListe().get(selectedIndex);
		
		model.addToWarenkorb(selected);
	}
	
	private void removeFromWarenkorb()
	{
		int selectedIndex = view.getWarenkorbList().getSelectedIndex();
		
		if(selectedIndex == -1) return;
		
		Artikel selected = model.getWarenkorbListe().get(selectedIndex);
		
		model.removeFromWarenkorb(selected);
	}
	
	private void submitBestellung()
	{
		
	}
	
}
