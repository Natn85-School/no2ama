package no2ama;
import java.awt.event.ActionListener;
import java.security.MessageDigest;

import javax.swing.DefaultListModel;

import java.awt.event.ActionEvent;

public class Controller implements ActionListener
{
	private No2ama view;
	private BestellungsSystem model;
	
	public Controller(No2ama view, BestellungsSystem model)
	{
		this.view = view;
		this.model = model;
		
		view.getBtnWarenkorb().addActionListener(this);
		view.getBtnArtikel().addActionListener(this);
		view.getBtnBestellungAbschicken().addActionListener(this);
		
		updateArtikelListe();
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == view.getBtnWarenkorb())
		{
			addToWarenkorb();
		}
		else if (e.getSource() == view.getBtnArtikel())
		{
			removeFromWarenkorb();
		} 
		else if (e.getSource() == view.getBtnBestellungAbschicken())
		{
			submitBestellung();
		}
	}
	
	private void addToWarenkorb()
	{
		int selectedIndex = view.getArtikelList().getSelectedIndex();
		
		if(selectedIndex == -1) return;
		
		Artikel selected = model.getArtikelListe().get(selectedIndex);
		
		model.getArtikelListe().remove(selected);
		model.addToWarenkorb(selected);
		
		updateArtikelListe();
		updateWarenkorbListe();
	}
	
	private void removeFromWarenkorb()
	{
		int selectedIndex = view.getWarenkorbList().getSelectedIndex();
		
		if(selectedIndex == -1) return;
		
		Artikel selected = model.getWarenkorbListe().get(selectedIndex);
		
		model.getArtikelListe().add(selected);
		model.removeFromWarenkorb(selected);
		
		updateArtikelListe();
		updateWarenkorbListe();
	}
	
	private void submitBestellung()
	{
		String kundenname = view.getKnameText().getText();
		
		if (kundenname.isEmpty()) return;
		
		model.submitBestellung(kundenname);
		view.getKnameText().setText("");
		
		javax.swing.JOptionPane.showMessageDialog(view.getFrame(), "Bestellung wurde gespeichert!", "Bestellung",javax.swing.JOptionPane.INFORMATION_MESSAGE);
		
		model.readArtikelFromFile("Artikeln.txt");
		updateArtikelListe();
		updateWarenkorbListe();
	}
	
	private void updateWarenkorbListe()
	{
		DefaultListModel<Artikel> listModel = new DefaultListModel<>();
		for (Artikel artikel:model.getWarenkorbListe())
		{
			listModel.addElement(artikel);
		}
		view.getWarenkorbList().setModel(listModel);
	}
	
	private void updateArtikelListe()
	{
		DefaultListModel<Artikel> listModel = new DefaultListModel<>();
		for (Artikel artikel:model.getArtikelListe())
		{
			listModel.addElement(artikel);
		}
		view.getArtikelList().setModel(listModel);
	}
}
