package no2ama;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class BestellungsSystem
{
	private ArrayList<Artikel> artikelListe;
	private ArrayList<Bestellung> bestellungListe;
	private ArrayList<Artikel> warenkorb;
	
	public void BestellungSystem()
	{
		artikelListe = new ArrayList<>();
		bestellungListe = new ArrayList<>();
		warenkorb = new ArrayList<>();
		
		readArtikelFromFile("Artikeln.txt");
	}
	
	private void readArtikelFromFile(String filename)
	{
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			String line;
			
			while ((line = reader.readLine()) != null)
			{
				String[] parts = line.split(";");
				int nummer = Integer.parseInt(parts[0].trim());
				String bezeichnung = parts[1].trim();
				String preisStr = parts[2].trim();
				
				preisStr = preisStr.replace("€", "").replace(",", ".").trim();
				double preis = Double.parseDouble(preisStr);
				
				Artikel artikel = new Artikel(nummer, bezeichnung, preis);
				artikelListe.add(artikel);
			}
			reader.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		public ArrayList<Artikel> getArtikelListe()
		{
			return artikelListe;
		}
		
		public ArrayList<Artikel> getWarenkorb()
		{
			return warenkorb;
		}
		
		public void addToWarenkorb(Artikel artikel)
		{
			
		}
		
		public void removeFromWarenkorb(Artikel artikel)
		{
			
		}
		
		public void submitBestellung(String kundenname)
		{
			
		}
	}

}
