/**
 * 
 */
/**
 * 
 */
module no2ama
{
	requires java.desktop;
}